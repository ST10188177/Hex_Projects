document.addEventListener('DOMContentLoaded', function() {
    const taskInput = document.getElementById('taskInput');
    const addTaskBtn = document.getElementById('addTaskBtn');
    const taskList = document.getElementById('taskList');
    const totalTasksSpan = document.getElementById('totalTasks');
    const completedTasksSpan = document.getElementById('completedTasks');
    const cloudsContainer = document.getElementById('clouds');
    
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    
    // Create floating clouds
    function createClouds() {
        for (let i = 0; i < 15; i++) {
            const cloud = document.createElement('div');
            cloud.classList.add('cloud');
            
            const size = Math.random() * 100 + 50;
            const left = Math.random() * 100;
            const top = Math.random() * 100;
            const opacity = Math.random() * 0.5 + 0.3;
            const duration = Math.random() * 20 + 10;
            
            cloud.style.width = `${size}px`;
            cloud.style.height = `${size * 0.6}px`;
            cloud.style.left = `${left}%`;
            cloud.style.top = `${top}%`;
            cloud.style.opacity = opacity;
            cloud.style.animationDuration = `${duration}s`;
            
            cloudsContainer.appendChild(cloud);
        }
    }
    
    createClouds();
    
    // Update stats
    function updateStats() {
        totalTasksSpan.textContent = `Total: ${tasks.length}`;
        const completed = tasks.filter(task => task.completed).length;
        completedTasksSpan.textContent = `Completed: ${completed}`;
    }
    
    // Save tasks to localStorage
    function saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(tasks));
        updateStats();
    }
    
    // Render tasks with edit functionality
    function renderTasks() {
        taskList.innerHTML = '';
        
        tasks.forEach((task, index) => {
            const li = document.createElement('li');
            if (task.completed) {
                li.classList.add('completed');
            }
            
            li.innerHTML = `
                <span class="task-text">${task.text}</span>
                <div class="task-actions">
                    <button class="edit-btn">✎</button>
                    <button class="complete-btn">✓</button>
                    <button class="delete-btn">✕</button>
                </div>
            `;
            
            const editBtn = li.querySelector('.edit-btn');
            const completeBtn = li.querySelector('.complete-btn');
            const deleteBtn = li.querySelector('.delete-btn');
            
            editBtn.addEventListener('click', () => enableEditMode(li, index));
            completeBtn.addEventListener('click', () => toggleComplete(index));
            deleteBtn.addEventListener('click', () => deleteTask(index));
            
            taskList.appendChild(li);
        });
        
        updateStats();
    }
    
    // Enable edit mode for a task
    function enableEditMode(taskElement, index) {
        const taskText = taskElement.querySelector('.task-text');
        const currentText = tasks[index].text;
        
        // Create input field
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentText;
        input.className = 'edit-input';
        
        // Replace text with input field
        taskText.replaceWith(input);
        input.focus();
        
        // Handle save on Enter or blur
        function saveEdit() {
            const newText = input.value.trim();
            if (newText && newText !== currentText) {
                tasks[index].text = newText;
                saveTasks();
            }
            renderTasks();
        }
        
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                saveEdit();
            }
        });
        
        input.addEventListener('blur', saveEdit);
    }
    
    // Add new task
    function addTask() {
        const text = taskInput.value.trim();
        if (text) {
            tasks.push({ text, completed: false });
            taskInput.value = '';
            saveTasks();
            renderTasks();
            
            // Add animation for new task
            const lastTask = taskList.lastChild;
            lastTask.style.transform = 'scale(0.9)';
            lastTask.style.opacity = '0';
            
            setTimeout(() => {
                lastTask.style.transform = 'scale(1)';
                lastTask.style.opacity = '1';
            }, 10);
        }
    }
    
    // Toggle task completion
    function toggleComplete(index) {
        tasks[index].completed = !tasks[index].completed;
        saveTasks();
        renderTasks();
    }
    
    // Delete task
    function deleteTask(index) {
        const taskItem = taskList.children[index];
        taskItem.style.transform = 'translateX(100px)';
        taskItem.style.opacity = '0';
        
        setTimeout(() => {
            tasks.splice(index, 1);
            saveTasks();
            renderTasks();
        }, 300);
    }
    
    // Event listeners
    addTaskBtn.addEventListener('click', addTask);
    taskInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') addTask();
    });
    
    // Initial render
    renderTasks();
    
    // Tilt effect on mouse move
    const island = document.querySelector('.floating-island');
    document.addEventListener('mousemove', (e) => {
        const x = e.clientX / window.innerWidth;
        const y = e.clientY / window.innerHeight;
        
        island.style.transform = `rotateY(${(x - 0.5) * 10}deg) rotateX(${(0.5 - y) * 10}deg)`;
    });
    
    // Reset tilt when mouse leaves
    document.addEventListener('mouseleave', () => {
        island.style.transform = 'rotateY(0) rotateX(0)';
    });
});